# =============================================================================
# 03_universum_pit.R  --  Point-in-Time-Universum ohne Survivorship Bias
# =============================================================================
#
# DAS PROBLEM IN EINEM SATZ:
# Wenn du heute eine Tickerliste ziehst und damit 2019 backtestest, testest du
# nur die Firmen, die es bis heute geschafft haben. Wirecard, Credit Suisse und
# jede uebernommene Bude fehlen. Die Rendite sieht dann fantastisch aus und ist
# komplett unerreichbar gewesen.
#
# UNSERE VIER VERTEIDIGUNGSLINIEN:
#
#   1. Tote Ticker sind im Universum drin. Rund 200 deiner RICs tragen ein
#      Delisting-Suffix (".N^J22"). Daraus lesen wir das Delisting-Datum
#      taggenau aus. Diese Firmen werden NICHT geloescht -- sie handeln bis
#      zu ihrem Datum ganz normal mit.
#
#   2. Stille Delistings finden. Manche Titel haben keinen Suffix, aber ihre
#      Kursreihe endet 2021 und hoert einfach auf. Wir behandeln das als
#      Delisting am letzten Kurstag.
#
#   3. Eine Position, die ins Delisting laeuft, wird nicht stillschweigend
#      ausgebucht, sondern mit einem Abschlag geschlossen (Default -30%,
#      siehe CFG$delist_return). Sonst verschwinden genau die Pleiten aus
#      der Statistik, die dich Geld gekostet haetten.
#
#   4. Kein Filter darf Zukunftswissen brauchen. Deshalb rechnen wir den
#      Liquiditaetsfilter (ADV) rollierend aus den Kursen -- und nutzen NICHT
#      die Spalte adv_3m aus dem LSEG-Export, denn die steht nur in der
#      ersten Zeile je Ticker und ist ein Heute-Wert.
#
# WAS DAS SKRIPT NOCH TUT:
# Technische Indikatoren rechnen (Momentum, RSI, ATR, 200-Tage-Linie) und das
# Ganze mit den Fundamentaldaten per rollierendem Join zu einem Panel
# verheiraten, in dem an jedem Tag nur steht, was an diesem Tag bekannt war.
#
# Ergebnis: data/proc/panel_rebal.rds  (Universum je Rebalance-Tag)
#           data/proc/px.rds           (Tagesrenditen + Delisting-Info)
# =============================================================================

source("00_config.R")

# 02 nur wegen yh_fetch_one() laden -- der Schalter verhindert, dass dabei
# der komplette Download-Hauptlauf von 02 mitstartet.
options(pead.lib_only = TRUE)
source("02_preise_yahoo.R")
options(pead.lib_only = FALSE)

# =============================================================================
# 1. WECHSELKURSE
# =============================================================================
# Volumen mal Kurs ergibt den Tagesumsatz in LOKALER Waehrung. 5 Mio KRW sind
# aber keine 5 Mio USD. Also brauchen wir Tageskurse fuer eine Handvoll
# Waehrungen -- das sind ca. 15 zusaetzliche Requests, kein Problem.

fetch_fx <- function(currencies) {
  currencies <- setdiff(unique(toupper(currencies[!is.na(currencies)])), "USD")
  msg("FX holen fuer: ", paste(currencies, collapse = ", "))

  out <- vector("list", length(currencies))
  for (k in seq_along(currencies)) {
    cur <- currencies[k]
    sym <- paste0(cur, "USD=X")      # z.B. KRWUSD=X = wie viel USD kostet 1 KRW
    r <- yh_fetch_one(sym, CFG$date_start, CFG$date_end)
    Sys.sleep(.yh_session$sleep)
    if (r$ok) out[[k]] <- data.table(currency = cur, date = r$data$date,
                                     fx_usd = r$data$close)
    else msg("  FX fehlgeschlagen: ", sym, " (", r$status, ")")
  }
  fx <- rbindlist(out)
  # USD auf 1 setzen
  if (nrow(fx)) {
    d <- sort(unique(fx$date))
    fx <- rbind(fx, data.table(currency = "USD", date = d, fx_usd = 1))
  }
  setorder(fx, currency, date)
  fx[]
}

# =============================================================================
# 2. TECHNISCHE INDIKATOREN
# =============================================================================
# Alles wird je Ticker gerechnet und schaut nur zurueck. Kein Indikator
# benutzt den heutigen Schlusskurs fuer ein Signal, das heute gehandelt wird --
# der Einstieg erfolgt spaeter ohnehin erst am naechsten Handelstag.

# RSI nach Wilder, ohne Zusatzpaket
rsi_wilder <- function(x, n = 14) {
  d <- c(NA_real_, diff(x))
  up <- pmax(d, 0); dn <- pmax(-d, 0)
  up[is.na(up)] <- 0; dn[is.na(dn)] <- 0   # sonst frisst ein NA die Rekursion
  # Wilder-Glaettung = exponentiell mit alpha = 1/n.
  # Startwert: einfacher Mittelwert der ersten n Werte.
  N <- length(x)
  au <- ad <- rep(NA_real_, N)
  if (N <= n) return(rep(NA_real_, N))
  au[n + 1] <- mean(up[2:(n + 1)], na.rm = TRUE)
  ad[n + 1] <- mean(dn[2:(n + 1)], na.rm = TRUE)
  for (i in (n + 2):N) {
    au[i] <- (au[i - 1] * (n - 1) + up[i]) / n
    ad[i] <- (ad[i - 1] * (n - 1) + dn[i]) / n
  }
  rs <- au / ifelse(ad == 0, NA_real_, ad)
  out <- 100 - 100 / (1 + rs)
  out[is.na(rs) & !is.na(au) & au > 0] <- 100
  out
}

# ATR in Prozent vom Kurs -- unser Volatilitaetsmass
atr_pct <- function(high, low, close, n = 14) {
  pc <- shift(close)
  tr <- pmax(high - low,
             abs(high - pc),
             abs(low - pc), na.rm = TRUE)
  roll_mean(tr, n) / close
}

add_technicals <- function(px) {
  setorder(px, id, date)

  # Tagesrendite aus dem BEREINIGTEN Kurs (Dividenden und Splits sind drin)
  px[, ret := adjclose / shift(adjclose) - 1, by = id]
  # Ein Sprung von mehr als 100% oder unter -80% an einem Tag ist fast immer
  # ein Datenfehler (fehlende Split-Anpassung). Rausnehmen, nicht mitrechnen.
  px[!is.na(ret) & (ret > 1 | ret < -0.8), ret := NA_real_]

  px[, n_obs := seq_len(.N), by = id]

  # --- Momentum ------------------------------------------------------------
  # 6-Monats-Performance (126 Handelstage). Das ist der Filter aus deinem
  # Tab 05, Zeile "Momentum".
  px[, perf_6m  := adjclose / shift(adjclose, 126) - 1, by = id]
  px[, perf_1m  := adjclose / shift(adjclose, 21)  - 1, by = id]
  # 12-1-Momentum: 12 Monate ohne den letzten Monat. Der Klassiker aus der
  # Literatur -- der letzte Monat dreht wegen kurzfristiger Umkehr oft ins
  # Gegenteil und verwaessert das Signal.
  px[, perf_12_1 := shift(adjclose, 21) / shift(adjclose, 252) - 1, by = id]
  px[n_obs < 127, perf_6m := NA_real_]
  px[n_obs < 253, perf_12_1 := NA_real_]

  # --- Trend, Schwankung, Ueberhitzung -------------------------------------
  px[, sma200    := roll_mean(adjclose, 200), by = id]
  px[, above_200 := as.integer(adjclose > sma200)]
  px[, rsi14     := rsi_wilder(adjclose, 14), by = id]
  px[, atr14     := atr_pct(high, low, close, 14), by = id]
  px[, vol_63    := roll_fun(ret, 63, sd, na.rm = TRUE), by = id]

  # --- Liquiditaet in USD --------------------------------------------------
  # Tagesumsatz = Volumen x Kurs x FX. Dann 63 Tage mitteln.
  px[, turnover_loc := volume * close]
  px[, adv63_usd := roll_mean(turnover_loc * fx_usd, 63), by = id]

  px[, c("n_obs", "turnover_loc") := NULL]
  px[]
}

# =============================================================================
# 3. LEBEN UND STERBEN JE TICKER
# =============================================================================

build_life <- function(px, universe) {

  life <- px[, .(first_px = min(date), last_px = max(date), n_px = .N), by = id]
  life <- merge(universe[, .(id, name, market, delist_date, is_dead)],
                life, by = "id", all.x = TRUE)

  data_end <- max(px$date)

  # --- Stille Delistings erkennen ------------------------------------------
  # Wenn die Kursreihe mehr als 15 Handelstage vor dem Datenende aufhoert und
  # der RIC kein Delisting-Suffix hat, ist der Titel trotzdem weg (Uebernahme,
  # Ticker-Wechsel, Yahoo-Luecke). Wir behandeln ihn als delistet.
  life[, silent_delist := !is.na(last_px) & is.na(delist_date) &
         last_px < data_end - 21]
  life[is.na(silent_delist), silent_delist := FALSE]

  # --- Effektives Delisting-Datum ------------------------------------------
  # Der frueheste der beiden Hinweise gewinnt. Wer laut RIC im Oktober 2022
  # verschwunden ist, aber schon im August keine Kurse mehr hat, ist im
  # August raus.
  # Achtung: pmin(x, y, na.rm = TRUE) wuerde bei fehlendem delist_date den
  # zweiten Wert nehmen und damit JEDEN lebenden Titel als tot markieren.
  # Deshalb explizit in drei Faellen denken:
  life[, delist_eff := as.Date(NA)]
  life[!is.na(delist_date),
       delist_eff := pmin(delist_date, last_px + 5, na.rm = TRUE)]
  life[is.na(delist_date) & silent_delist, delist_eff := last_px]

  # --- Grund des Abgangs ----------------------------------------------------
  # Fuer die Delisting-Rendite unterscheiden wir grob:
  #   "ric"    = laut Refinitiv delistet, Grund unbekannt -> Abschlag anwenden
  #   "silent" = Kurse hoeren auf, kein Suffix -> meist Uebernahme, oft mit
  #              Praemie. Wir wenden hier KEINEN Abschlag an, sondern schliessen
  #              zum letzten Kurs.
  life[, delist_type := fifelse(!is.na(delist_date), "ric",
                        fifelse(silent_delist, "silent", NA_character_))]

  msg("Lebenszyklus: ", nrow(life), " Ticker | ",
      sum(!is.na(life$delist_date)), " mit RIC-Delisting | ",
      sum(life$silent_delist, na.rm = TRUE), " stille Abgaenge | ",
      sum(is.na(life$n_px)), " ganz ohne Kursdaten")
  life[]
}

# =============================================================================
# 4. REBALANCE-KALENDER UND PANEL
# =============================================================================

build_calendar <- function(px) {
  # Handelstage = alle Tage, an denen mindestens 30% des Universums handelt.
  # Damit fliegen einzelne Feiertagsboersen raus, ohne dass wir eine
  # Feiertagsdatenbank brauchen.
  cnt <- px[, .N, by = date][order(date)]
  cnt[, share := N / max(N)]
  cal <- cnt[share >= 0.30, date]
  msg("Handelskalender: ", length(cal), " Tage.")
  sort(cal)
}

#' Panel je Rebalance-Tag bauen
#'
#' Der Kern ist ein ROLLIERENDER JOIN: fuer jeden Ticker und jeden
#' Rebalance-Tag suchen wir das letzte Quartal, dessen known_from (also das
#' Berichtsdatum) am oder vor diesem Tag liegt. Alles Spaetere ist unsichtbar.
#' Genau das ist Point-in-Time.
build_panel <- function(px, fund, life, calendar) {

  # Rebalance-Tage: jeder Montag (bzw. der naechste Handelstag)
  all_mon <- seq(CFG$date_bt_start, max(calendar), by = "week")
  all_mon <- all_mon + (CFG$rebal_weekday - as.integer(format(all_mon, "%u")))
  rebal <- unique(next_trading_day(all_mon, calendar))
  rebal <- rebal[!is.na(rebal)]
  msg("Rebalance-Tage: ", length(rebal))

  # Alle Ticker x alle Rebalance-Tage, aber nur solange sie leben
  base <- CJ(id = unique(px$id), date = rebal)
  base[, date := as.Date(date, origin = "1970-01-01")]  # CJ verliert je nach
                                                        # data.table-Version
                                                        # die Datumsklasse
  base <- merge(base, life[, .(id, market, delist_eff, delist_type, first_px)],
                by = "id", all.x = TRUE)
  base <- base[is.na(delist_eff) | date < delist_eff]
  base <- base[is.na(first_px)  | date >= first_px]

  # --- Technik anhaengen (exakter Join auf den Rebalance-Tag) --------------
  tech_cols <- c("id", "date", "close", "adjclose", "ret", "perf_6m", "perf_1m",
                 "perf_12_1", "above_200", "rsi14", "atr14", "vol_63",
                 "adv63_usd", "fx_usd")
  base <- merge(base, px[, ..tech_cols], by = c("id", "date"), all.x = TRUE)

  # Wer am Rebalance-Tag keinen Kurs hat (Feiertag an seiner Boerse), bekommt
  # den letzten verfuegbaren -- per rollierendem Join, maximal 7 Tage zurueck.
  miss <- base[is.na(close), .(id, date)]
  if (nrow(miss)) {
    setkey(px, id, date)
    filled <- px[miss, ..tech_cols, on = .(id, date), roll = 7]
    base[filled, on = .(id, date),
         `:=`(close = i.close, adjclose = i.adjclose, perf_6m = i.perf_6m,
              perf_1m = i.perf_1m, perf_12_1 = i.perf_12_1,
              above_200 = i.above_200, rsi14 = i.rsi14, atr14 = i.atr14,
              vol_63 = i.vol_63, adv63_usd = i.adv63_usd, fx_usd = i.fx_usd)]
  }

  # --- Fundamentaldaten per rollierendem Join -------------------------------
  fcols <- c("id", "known_from", "period_end", "industry", "mktcap_usd",
             "rev_ttm", "ni_ttm", "eps_ttm", "net_margin", "gross_margin",
             "fcf_margin", "debt_equity", "pe", "roe", "accruals",
             "rev_yoy", "eps_yoy", "sue", "eps_surprise", "pred_surprise",
             "rev_surprise", "surp_hit_rate4", "price_target", "rec_mean")
  f <- fund[, ..fcols]
  setkey(f, id, known_from)

  base[, join_date := date]
  panel <- f[base, on = .(id, known_from = join_date), roll = TRUE]
  setnames(panel, "known_from", "known_from_used")

  # Veraltete Daten aussortieren: wer seit 200 Tagen nichts berichtet hat,
  # ist entweder in Schwierigkeiten oder aus der Abdeckung gefallen.
  # Solche Zeilen fliegen ganz raus -- ein Titel ohne verwertbare Fundamentals
  # ist an diesem Tag schlicht nicht investierbar.
  panel[, data_age := as.numeric(date - known_from_used)]
  n_before <- nrow(panel)
  panel <- panel[!is.na(data_age) & data_age <= CFG$max_stale_days]
  msg("  ", format(n_before - nrow(panel), big.mark = "."),
      " Zeilen wegen veralteter/fehlender Fundamentals verworfen.")

  # Kursbezogene Kennzahl, die beide Quellen braucht
  panel[, target_upside := safe_div(price_target, close) - 1]

  setorder(panel, date, id)
  msg("Panel: ", format(nrow(panel), big.mark = "."), " Zeilen (",
      uniqueN(panel$id), " Ticker x ", uniqueN(panel$date), " Tage)")
  panel[]
}

# =============================================================================
# HAUPTLAUF
# =============================================================================

if (run_main()) {

  universe <- readRDS(file.path(CFG$dir_proc, "universe.rds"))
  fund     <- readRDS(file.path(CFG$dir_proc, "fundamentals.rds"))
  px       <- readRDS(file.path(CFG$dir_proc, "prices.rds"))

  # --- FX ------------------------------------------------------------------
  fx_file <- file.path(CFG$dir_proc, "fx.rds")
  if (file.exists(fx_file)) {
    fx <- readRDS(fx_file)
  } else {
    fx <- fetch_fx(unique(px$currency))
    saveRDS(fx, fx_file)
  }
  setkey(fx, currency, date)
  px[, currency := toupper(currency)]
  px[is.na(currency), currency := "USD"]
  # Rollierender Join, damit Feiertage im FX-Kalender kein Loch reissen
  px <- fx[px, on = .(currency, date), roll = TRUE]
  px[is.na(fx_usd), fx_usd := 1]

  # --- Technik, Leben, Kalender, Panel -------------------------------------
  px    <- add_technicals(px)
  life  <- build_life(px, universe)
  cal   <- build_calendar(px)
  panel <- build_panel(px, fund, life, cal)

  saveRDS(px[, .(id, date, close, adjclose, ret, fx_usd, adv63_usd)],
          file.path(CFG$dir_proc, "px.rds"))
  saveRDS(life,  file.path(CFG$dir_proc, "life.rds"))
  saveRDS(cal,   file.path(CFG$dir_proc, "calendar.rds"))
  saveRDS(panel, file.path(CFG$dir_proc, "panel_rebal.rds"))

  # --- Kontrolle: waechst das investierbare Universum ueber die Zeit? -------
  # Wenn die Zahl der investierbaren Titel im Zeitverlauf konstant steigt und
  # NIE faellt, hast du trotz allem noch Survivorship Bias drin.
  ok <- panel[!is.na(mktcap_usd) & mktcap_usd >= CFG$min_mktcap &
                !is.na(adv63_usd) & adv63_usd >= CFG$min_adv_usd,
              .(n_investierbar = .N), by = date]
  print(ok[seq(1, .N, by = 26)])
}
