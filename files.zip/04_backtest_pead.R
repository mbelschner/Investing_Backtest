# =============================================================================
# 04_backtest_pead.R  --  Post-Earnings-Announcement-Drift backtesten
# =============================================================================
#
# DIE IDEE HINTER PEAD:
# Wenn eine Firma die Erwartungen schlaegt, springt der Kurs am Tag danach --
# aber er springt nicht weit genug. Ueber die naechsten Wochen laeuft er
# langsam weiter in dieselbe Richtung. Der Markt verarbeitet die Nachricht
# zu traege. Das ist einer der aeltesten und robustesten dokumentierten
# Effekte, und die Halbwertszeit passt exakt zu deinen 90 Tagen Haltedauer.
#
# WIE WIR IHN TESTEN:
#   1. Jedes Quartalsergebnis ist ein EVENT.
#   2. Einstieg einen Handelstag NACH dem Bericht (nicht am Berichtstag --
#      das waere Zeitreise, weil Berichte oft nach Boersenschluss kommen).
#   3. 90 Kalendertage halten, dann raus. Oder frueher, wenn der Titel
#      delistet wird.
#   4. Ausgewaehlt wird nur, wer die Filter aus Tab 05 besteht -- und die
#      Raenge werden gegen das GESAMTE investierbare Universum an diesem Tag
#      gebildet, nicht nur gegen die Firmen, die zufaellig diese Woche
#      berichten.
#
# VIER VARIANTEN, VORAB DEFINIERT:
#   (a) tv_original  -- dein urspruenglicher TradingView-Screener
#   (b) reduziert    -- ohne die redundanten Margen-Filter
#   (c) rangbasiert  -- Terzile statt absoluter Schwellen (Tab 05 v2)
#   (d) estimates    -- (c) plus Predicted Surprise und Surprise-Historie
#
# Alle vier werden GEMEINSAM gerechnet und die Signifikanz wird fuer die Zahl
# der Versuche korrigiert (Deflated Sharpe Ratio). Genau das steht in deiner
# Zeile 30 von Tab 05: nicht sequenziell testen, bis eine gut aussieht.
#
# Ergebnis: output/backtest_summary.csv, output/equity_curves.rds
# =============================================================================

source("00_config.R")

# =============================================================================
# 1. EVENTS BAUEN
# =============================================================================

build_events <- function(fund, calendar) {

  ev <- fund[!is.na(known_from) & !is.na(eps_actual),
             .(id, period_end, known_from, industry,
               eps_actual, eps_mean_est, eps_smart_est,
               sue, eps_surprise, pred_surprise, rev_surprise,
               surp_hit_rate4, rec_mean)]

  # Einstieg: entry_lag Handelstage NACH dem Berichtstag.
  # findInterval sucht die Position des Berichtstags im Handelskalender,
  # dann zaehlen wir die gewuenschten Tage weiter.
  pos <- findInterval(ev$known_from, calendar)
  idx <- pos + CFG$entry_lag
  idx[idx < 1L | idx > length(calendar)] <- NA_integer_
  ev[, entry_date := calendar[idx]]

  # Geplanter Ausstieg: 90 Kalendertage spaeter, auf den naechsten Handelstag
  ev[, exit_plan := next_trading_day(entry_date + CFG$hold_days, calendar)]
  # Events, deren Haltedauer noch laeuft, fliegen raus -- sonst mischen sich
  # halbe Trades in die Statistik.
  ev <- ev[!is.na(entry_date) & !is.na(exit_plan)]
  ev <- ev[entry_date >= CFG$date_bt_start]

  # Rebalance-Woche zuordnen: der Rebalance-Tag, an oder nach dem der
  # Einstieg faellt. An diesem Tag bilden wir die Rangfolge.
  msg("Events: ", nrow(ev), " Quartalsberichte im Backtest-Fenster (",
      format(min(ev$entry_date)), " bis ", format(max(ev$entry_date)), ")")
  ev[]
}

# =============================================================================
# 2. QUERSCHNITTS-RAENGE JE REBALANCE-TAG
# =============================================================================
# Wichtig: Raenge werden ueber das INVESTIERBARE Universum gebildet, nicht
# ueber die Auswahl. Ein KGV im untersten Terzil heisst "guenstiger als zwei
# Drittel aller handelbaren Aktien an diesem Tag" -- und nicht "guenstiger
# als die 12 anderen, die diese Woche berichtet haben".

add_ranks <- function(panel) {

  # Hygiene zuerst -- nur wer investierbar ist, kommt in die Rangfolge
  panel[, investierbar :=
          !is.na(mktcap_usd)  & mktcap_usd >= CFG$min_mktcap &
          !is.na(adv63_usd)   & adv63_usd  >= CFG$min_adv_usd &
          !is.na(close)]

  iv <- panel[investierbar == TRUE]

  rank_cols <- c("rev_yoy", "roe", "pe", "perf_6m", "pred_surprise",
                 "sue", "eps_yoy", "fcf_margin", "accruals")
  for (cc in rank_cols) {
    if (cc %in% names(iv))
      iv[, paste0("r_", cc) := prank(get(cc)), by = date]
  }
  # z-Scores fuer die Regression spaeter
  for (cc in rank_cols) {
    if (cc %in% names(iv))
      iv[, paste0("z_", cc) := zscore(get(cc)), by = date]
  }

  iv[, n_universe := .N, by = date]
  msg("Investierbares Universum: Median ",
      round(median(iv[, .N, by = date]$N)), " Titel je Rebalance-Tag.")
  iv[]
}

# =============================================================================
# 3. DIE VIER FILTERVARIANTEN
# =============================================================================
# Jede Funktion bekommt den Querschnitt eines Rebalance-Tages und gibt einen
# TRUE/FALSE-Vektor zurueck: wer darf gekauft werden?
#
# Hygiene (Groesse, Liquiditaet, Ausreisser, Basiseffekt) ist ueberall gleich
# und steckt in apply_hygiene(). Die Varianten unterscheiden sich nur in den
# eigentlichen Auswahlkriterien.

apply_hygiene <- function(d) {
  ok <- rep(TRUE, nrow(d))
  ok <- ok & !is.na(d$mktcap_usd) & d$mktcap_usd >= CFG$min_mktcap
  ok <- ok & !is.na(d$adv63_usd)  & d$adv63_usd  >= CFG$min_adv_usd
  # Ausreisser-Wachstum raus (Zeile 17 in Tab 05)
  ok <- ok & (is.na(d$rev_yoy) | d$rev_yoy <= CFG$max_growth)
  ok <- ok & (is.na(d$eps_yoy) | d$eps_yoy <= CFG$max_growth)
  # Basiseffekt-Guard: eps_yoy ist per Konstruktion nur dann nicht NA, wenn
  # das Vorjahres-EPS positiv war (siehe Skript 01).
  ok
}

# (a) Dein urspruenglicher TradingView-Screener, so gut es die Daten hergeben
var_tv_original <- function(d) {
  apply_hygiene(d) &
    !is.na(d$rev_yoy)      & d$rev_yoy      > 0.10 &
    !is.na(d$roe)          & d$roe          > 0.15 &
    !is.na(d$pe)           & d$pe > 0 & d$pe < 25 &
    !is.na(d$debt_equity)  & d$debt_equity  < 1.5 &
    !is.na(d$net_margin)   & d$net_margin   > 0.07 &
    !is.na(d$gross_margin) & d$gross_margin > 0.15 &
    !is.na(d$rsi14)        & d$rsi14        < 75
}

# (b) Reduziert: Margen-Filter raus (redundant zu ROE, siehe Tab 05 Zeile 28/29),
#     RSI raus (Halbwertszeit Tage, du haeltst 90)
var_reduziert <- function(d) {
  apply_hygiene(d) &
    !is.na(d$rev_yoy)     & d$rev_yoy     > 0.10 &
    !is.na(d$roe)         & d$roe         > 0.15 &
    !is.na(d$pe)          & d$pe > 0 & d$pe < 25 &
    !is.na(d$debt_equity) & d$debt_equity < 1.5 &
    !is.na(d$fcf_margin)  & d$fcf_margin  > 0
}

# (c) Rangbasiert -- Tab 05 v2. Terzile statt absoluter Schwellen, damit die
#     Portfoliogroesse ueber Regimes stabil bleibt.
var_rangbasiert <- function(d) {
  apply_hygiene(d) &
    !is.na(d$r_rev_yoy)   & d$r_rev_yoy   >= 1 - 0.333 &   # oberstes Terzil
    !is.na(d$r_roe)       & d$r_roe       >= 1 - 0.333 &
    !is.na(d$pe) & d$pe > 0 & !is.na(d$r_pe) & d$r_pe <= 0.50 &
    !is.na(d$debt_equity) & d$debt_equity < 1.5 &
    !is.na(d$r_perf_6m)   & d$r_perf_6m   >= 1 - 0.333 &
    !is.na(d$fcf_margin)  & d$fcf_margin  > 0
}

# (d) Rangbasiert plus Estimates -- die eigentliche PEAD-Variante
var_estimates <- function(d) {
  var_rangbasiert(d) &
    !is.na(d$r_pred_surprise) & d$r_pred_surprise >= 0.50 &
    !is.na(d$eps_surprise)    & d$eps_surprise    > 0
}

VARIANTS <- list(
  a_tv_original = var_tv_original,
  b_reduziert   = var_reduziert,
  c_rangbasiert = var_rangbasiert,
  d_estimates   = var_estimates
)

# =============================================================================
# 4. SEKTOR-CAP
# =============================================================================
# Ohne diesen Schritt misst du bei einem Universum mit Samsung, SK Hynix,
# TSMC und MediaTek den Halbleiterzyklus und nennst es Strategie.

apply_sector_cap <- function(sel, score_col = "sue") {
  if (is.null(sel) || nrow(sel) == 0) return(sel)
  s <- copy(sel)
  # Wer den hoechsten Score hat, darf bleiben. Ohne Score ans Ende.
  s[, .score := as.numeric(get(score_col))]
  s[is.na(.score), .score := -Inf]
  setorder(s, date, -.score)
  s[, n_sel := .N, by = date]
  s[, n_max := pmax(1L, as.integer(floor(CFG$sector_cap * n_sel)))]
  s[, rk_ind := seq_len(.N), by = .(date, industry)]
  out <- s[rk_ind <= n_max]
  out[, c(".score", "n_sel", "n_max", "rk_ind") := NULL]
  out[]
}

# =============================================================================
# 5. AUSWAHL LAUFEN LASSEN
# =============================================================================

select_positions <- function(events, iv, variant_name, variant_fun) {

  # Die Signale des Events (Surprise etc.) an den Universums-Querschnitt
  # am Einstiegstag heften.
  ev <- copy(events)
  ev[, date := entry_date]

  d <- merge(ev, iv, by = c("id", "date"),
             all.x = FALSE, suffixes = c("", ".p"))
  if (nrow(d) == 0) return(NULL)

  keep <- variant_fun(d)
  keep[is.na(keep)] <- FALSE
  sel <- d[keep]
  if (nrow(sel) == 0) return(NULL)

  sel <- apply_sector_cap(sel, "sue")

  sel[, variant := variant_name]
  sel[, .(variant, id, industry, date, entry_date, exit_plan, period_end,
          sue, eps_surprise, pred_surprise, rev_surprise, perf_6m, roe, pe,
          rev_yoy, fcf_margin, debt_equity, accruals, rsi14, close)]
}

# =============================================================================
# 6. PORTFOLIO SIMULIEREN
# =============================================================================

simulate <- function(pos, px, life, bench) {

  if (is.null(pos) || nrow(pos) == 0) return(NULL)

  # --- Delisting in die Haltedauer einbauen --------------------------------
  pos <- merge(pos, life[, .(id, delist_eff, delist_type)], by = "id",
               all.x = TRUE)
  pos[, forced := !is.na(delist_eff) & delist_eff <= exit_plan]
  pos[, exit_date := fifelse(forced, delist_eff, exit_plan)]
  pos <- pos[exit_date > entry_date]

  # --- Haltetage aufblasen -------------------------------------------------
  # Non-equi Join: nimm aus dem Kurspanel jeden Tag, der zwischen Einstieg und
  # Ausstieg liegt. "x." = Kurspanel, "i." = Positionsliste.
  hold <- px[pos,
             on = .(id, date >= entry_date, date <= exit_date),
             .(variant   = i.variant,
               id        = x.id,
               date      = x.date,
               ret       = x.ret,
               entry_date= i.entry_date,
               exit_date = i.exit_date,
               forced    = i.forced,
               delist_type = i.delist_type),
             nomatch = NULL, allow.cartesian = TRUE]
  hold[is.na(ret), ret := 0]

  # --- Kosten --------------------------------------------------------------
  cost <- CFG$cost_bps / 1e4
  hold[date == entry_date, ret := ret - cost]
  hold[date == exit_date,  ret := ret - cost]

  # --- Delisting-Rendite ---------------------------------------------------
  # Nur bei RIC-Delistings ohne bekannten Grund. Stille Abgaenge sind meist
  # Uebernahmen -- die schliessen wir zum letzten Kurs ohne Abschlag.
  hold[date == exit_date & forced == TRUE & delist_type == "ric",
       ret := ret + CFG$delist_return]

  # --- Tagesrendite des Portfolios ----------------------------------------
  # Gleichgewichtet ueber ALLE offenen Positionen. Weil sich die 90-Tage-
  # Kohorten ueberlappen, laufen typischerweise 12-13 Wochenkohorten
  # gleichzeitig -- das ist die uebliche Umsetzung ueberlappender
  # Event-Portfolios.
  eq <- hold[, .(ret = mean(ret, na.rm = TRUE), n_pos = .N),
             by = .(variant, date)][order(variant, date)]

  eq <- merge(eq, bench, by = "date", all.x = TRUE)
  eq[is.na(bench_ret), bench_ret := 0]
  eq[, excess := ret - bench_ret]
  eq[, equity := cumprod(1 + ret), by = variant]
  eq[, equity_bench := cumprod(1 + bench_ret), by = variant]

  list(equity = eq[], holdings = hold[], positions = pos[])
}

# =============================================================================
# 7. KENNZAHLEN
# =============================================================================

perf_stats <- function(r, freq = 252) {
  r <- r[!is.na(r)]
  n <- length(r)
  if (n < 30) return(NULL)
  cum   <- prod(1 + r)
  years <- n / freq
  cagr  <- cum^(1 / years) - 1
  vol   <- sd(r) * sqrt(freq)
  sr    <- if (vol > 0) (mean(r) * freq) / vol else NA_real_
  eqty  <- cumprod(1 + r)
  dd    <- eqty / cummax(eqty) - 1
  data.table(
    n_tage   = n,
    cagr     = cagr,
    vol_pa   = vol,
    sharpe   = sr,
    max_dd   = min(dd),
    calmar   = if (min(dd) < 0) cagr / abs(min(dd)) else NA_real_,
    hit_tage = mean(r > 0),
    skew     = mean((r - mean(r))^3) / sd(r)^3,
    kurt     = mean((r - mean(r))^4) / sd(r)^4
  )
}

#' Deflated Sharpe Ratio (Bailey & Lopez de Prado)
#'
#' Die Frage, die sie beantwortet: Ich habe N Strategien ausprobiert und die
#' beste hat Sharpe X. Wie wahrscheinlich ist es, dass X echt ist und nicht
#' der beste von N Zufallstreffern?
#'
#' Achtung: sr_obs und sr_all muessen in derselben Frequenz vorliegen wie
#' n_obs. Also TAEGLICHE Sharpe Ratios bei taeglichen Beobachtungen -- nicht
#' die annualisierte Zahl einsetzen.
deflated_sharpe <- function(sr_obs, sr_all, n_obs, skew = 0, kurt = 3,
                            n_trials = NULL) {
  # n_trials: die EHRLICHE Zahl der Versuche. Nicht nur die vier Varianten
  # unten, sondern alles, was du je an diesem Universum ausprobiert hast --
  # jede Parametervariante, jeder verworfene Filter zaehlt mit. Setz das
  # bewusst hoch (CFG$n_trials), sonst ist die Deflation wertlos.
  N <- if (is.null(n_trials)) length(sr_all) else max(n_trials, length(sr_all))
  if (length(sr_all) < 2) return(NA_real_)
  v <- var(sr_all)
  emc <- 0.5772156649015329          # Euler-Mascheroni
  # Erwarteter Maximal-Sharpe aus N reinen Zufallsstrategien
  sr0 <- sqrt(v) * ((1 - emc) * qnorm(1 - 1 / N) +
                      emc * qnorm(1 - 1 / (N * exp(1))))
  den <- sqrt(1 - skew * sr_obs + ((kurt - 1) / 4) * sr_obs^2)
  if (is.na(den) || den <= 0) return(NA_real_)
  pnorm((sr_obs - sr0) * sqrt(n_obs - 1) / den)
}

# =============================================================================
# 8. PERMUTATIONSTEST
# =============================================================================
# Die ehrlichste Frage an jeden Backtest: haette ein Affe mit denselben
# Einstiegsterminen und derselben Anzahl Positionen dasselbe erreicht?
#
# Wir tauschen die AUSWAHL gegen Zufall, lassen Zeitpunkte und Portfoliogroesse
# unveraendert und schauen, wie oft der Zufall die echte Strategie schlaegt.
# Wenn das in 30% der Faelle passiert, hast du kein Signal, sondern Beta.

permutation_test <- function(events, iv, px, life, bench, sel_real, B = 200,
                             seed = 42) {
  set.seed(seed)
  if (is.null(sel_real) || nrow(sel_real) == 0) return(NULL)

  # Wie viele Positionen wurden je Tag eroeffnet?
  n_by_date <- sel_real[, .(n_take = .N), by = date]
  ev <- copy(events); ev[, date := entry_date]
  pool <- merge(ev[, .(id, date, entry_date, exit_plan)],
                iv[, .(id, date, industry, mktcap_usd, adv63_usd)],
                by = c("id", "date"))
  pool <- pool[mktcap_usd >= CFG$min_mktcap & adv63_usd >= CFG$min_adv_usd]
  pool <- merge(pool, n_by_date, by = "date")   # nur Tage, an denen die echte
                                                # Strategie auch gekauft hat

  srs <- numeric(B)
  pb <- txtProgressBar(min = 0, max = B, style = 3)
  for (b in seq_len(B)) {
    setTxtProgressBar(pb, b)
    draw <- pool[, .SD[sample(.N, min(.N, n_take[1]))], by = date]
    p <- draw[, .(id, variant = "perm", date, entry_date, exit_plan,
                  industry)]
    s <- simulate(p, px, life, bench)
    srs[b] <- if (is.null(s)) NA_real_ else {
      st <- perf_stats(s$equity$ret); if (is.null(st)) NA_real_ else st$sharpe
    }
  }
  close(pb)
  srs[!is.na(srs)]
}

# =============================================================================
# 9. FAMA-MACBETH: WELCHES SIGNAL TRAEGT DEN DRIFT?
# =============================================================================
# Statt zu fragen "funktioniert das Portfolio", fragen wir "welche Variable
# erklaert die Rendite der naechsten 90 Tage". Je Rebalance-Tag eine
# Querschnittsregression, danach den Mittelwert der Koeffizienten ueber die
# Zeit mit t-Wert. Das ist der Standardweg, ein Signal zu zerlegen.

fama_macbeth <- function(events, iv, px, calendar,
                         signals = c("z_sue", "z_pred_surprise", "z_perf_6m",
                                     "z_roe", "z_pe", "z_rev_yoy",
                                     "z_fcf_margin", "z_accruals")) {

  ev <- copy(events); ev[, date := entry_date]
  d <- merge(ev, iv, by = c("id", "date"))

  # Forward-Rendite ueber die Haltedauer, marktbereinigt.
  # Zwei rollierende Joins: Kurs am Einstiegstag und Kurs am Ausstiegstag.
  # roll = 5 heisst: falls an dem Tag kein Kurs vorliegt (Feiertag), nimm den
  # letzten Kurs der vorangegangenen fuenf Tage.
  fwd <- px[, .(id, date, adjclose)]
  setkey(fwd, id, date)
  tin  <- fwd[d[, .(id, date = entry_date)], on = .(id, date), roll = 5]
  tout <- fwd[d[, .(id, date = exit_plan)],  on = .(id, date), roll = 5]
  d[, px_in  := tin$adjclose]
  d[, px_out := tout$adjclose]
  d[, fwd_ret := px_out / px_in - 1]

  # Marktbereinigung: Rendite minus Median des Querschnitts am selben Tag
  d[, fwd_abn := fwd_ret - median(fwd_ret, na.rm = TRUE), by = date]
  d <- d[is.finite(fwd_abn)]

  sig <- intersect(signals, names(d))
  fm <- d[, {
    if (.N < 20) NULL else {
      X <- as.data.frame(.SD[, ..sig])
      ok <- complete.cases(X) & is.finite(fwd_abn)
      if (sum(ok) < 20) NULL else {
        fit <- lm(fwd_abn[ok] ~ ., data = X[ok, , drop = FALSE])
        as.list(coef(fit))
      }
    }
  }, by = date, .SDcols = c(sig, "fwd_abn")]

  if (nrow(fm) == 0) return(NULL)
  cols <- setdiff(names(fm), "date")
  res <- rbindlist(lapply(cols, function(cc) {
    v <- fm[[cc]]; v <- v[is.finite(v)]
    data.table(variable = cc, mittel = mean(v), n = length(v),
               t_wert = mean(v) / (sd(v) / sqrt(length(v))))
  }))
  res[order(-abs(t_wert))]
}

# =============================================================================
# HAUPTLAUF
# =============================================================================

if (run_main()) {

  fund  <- readRDS(file.path(CFG$dir_proc, "fundamentals.rds"))
  panel <- readRDS(file.path(CFG$dir_proc, "panel_rebal.rds"))
  px    <- readRDS(file.path(CFG$dir_proc, "px.rds"))
  life  <- readRDS(file.path(CFG$dir_proc, "life.rds"))
  cal   <- readRDS(file.path(CFG$dir_proc, "calendar.rds"))

  events <- build_events(fund, cal)
  iv     <- add_ranks(panel)

  # --- Benchmark: gleichgewichtetes, liquides Universum --------------------
  bench <- px[!is.na(adv63_usd) & adv63_usd >= CFG$min_adv_usd & !is.na(ret),
              .(bench_ret = mean(ret)), by = date][order(date)]

  # --- Alle vier Varianten rechnen -----------------------------------------
  results <- list()
  for (nm in names(VARIANTS)) {
    msg("--- Variante: ", nm)
    sel <- select_positions(events, iv, nm, VARIANTS[[nm]])
    if (is.null(sel) || nrow(sel) == 0) {
      msg("    keine Positionen -- Filter zu eng."); next
    }
    sim <- simulate(sel, px, life, bench)
    st  <- perf_stats(sim$equity$ret)
    stb <- perf_stats(sim$equity$excess)
    if (is.null(st)) {
      msg("    zu wenige Handelstage fuer eine Auswertung -- uebersprungen.")
      next
    }
    if (is.null(stb)) stb <- data.table(sharpe = NA_real_)
    results[[nm]] <- list(sel = sel, sim = sim, stats = st, stats_excess = stb)
    msg("    ", nrow(sel), " Trades | Sharpe ", round(st$sharpe, 2),
        " | CAGR ", round(100 * st$cagr, 1), "% | MaxDD ",
        round(100 * st$max_dd, 1), "%")
  }
  stopifnot(length(results) > 0)

  # --- Zusammenfassung ------------------------------------------------------
  summary_dt <- rbindlist(lapply(names(results), function(nm) {
    cbind(variante = nm,
          n_trades = nrow(results[[nm]]$sel),
          results[[nm]]$stats,
          sharpe_excess = results[[nm]]$stats_excess$sharpe)
  }))

  # --- Deflated Sharpe ------------------------------------------------------
  # WICHTIG: hier taegliche (nicht annualisierte) Sharpe Ratios einsetzen.
  daily_sr <- vapply(results, function(x) {
    r <- x$sim$equity$ret; mean(r, na.rm = TRUE) / sd(r, na.rm = TRUE)
  }, numeric(1))

  summary_dt[, sr_daily := daily_sr[variante]]
  summary_dt[, dsr := mapply(function(s, sk, ku, nn)
    deflated_sharpe(s, daily_sr, nn, sk, ku, n_trials = CFG$n_trials),
    sr_daily, skew, kurt, n_tage)]

  msg("=== Ergebnis ===")
  print(summary_dt[, .(variante, n_trades, cagr = round(cagr, 3),
                       sharpe = round(sharpe, 2),
                       sharpe_excess = round(sharpe_excess, 2),
                       max_dd = round(max_dd, 3),
                       dsr = round(dsr, 3))])
  msg("DSR nahe 1 = das Ergebnis ueberlebt die Korrektur fuer ",
      length(daily_sr), " Versuche. Unter 0,95 = nicht ueberzeugend.")

  # --- Permutationstest fuer die beste Variante ----------------------------
  best <- summary_dt[which.max(sharpe), variante]
  msg("Permutationstest fuer: ", best)
  null_sr <- permutation_test(events, iv, px, life, bench,
                              results[[best]]$sel, B = 200)
  if (length(null_sr)) {
    p_emp <- mean(null_sr >= summary_dt[variante == best, sharpe])
    msg("Zufalls-Sharpe: Median ", round(median(null_sr), 2),
        " | 95%-Quantil ", round(quantile(null_sr, 0.95), 2),
        " | empirischer p-Wert ", round(p_emp, 3))
  }

  # --- Signalzerlegung ------------------------------------------------------
  msg("Fama-MacBeth: welches Signal traegt den Drift?")
  fm <- fama_macbeth(events, iv, px, cal)
  print(fm)

  # --- Speichern ------------------------------------------------------------
  fwrite(summary_dt, file.path(CFG$dir_out, "backtest_summary.csv"))
  saveRDS(lapply(results, function(x) x$sim$equity),
          file.path(CFG$dir_out, "equity_curves.rds"))
  saveRDS(results, file.path(CFG$dir_out, "backtest_full.rds"))
  if (!is.null(fm)) fwrite(fm, file.path(CFG$dir_out, "fama_macbeth.csv"))

  # --- Sensitivitaet Delisting-Rendite -------------------------------------
  # Wenn die Strategie bei -55% zusammenbricht, haengt dein Ergebnis an einer
  # Annahme und nicht an einem Effekt.
  msg("Sensitivitaet der Delisting-Annahme (beste Variante):")
  old_dr <- CFG$delist_return
  for (dr in c(0, -0.30, -0.55)) {
    CFG$delist_return <- dr        # simulate() liest CFG aus dem globalen Env
    s  <- simulate(results[[best]]$sel, px, life, bench)
    st <- perf_stats(s$equity$ret)
    msg("  delist_return = ", dr, " -> Sharpe ", round(st$sharpe, 2),
        " | CAGR ", round(100 * st$cagr, 1), "%")
  }
  CFG$delist_return <- old_dr
}
