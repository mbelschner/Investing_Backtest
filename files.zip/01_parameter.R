# =============================================================================
# 01_parameter.R  --  LSEG-Exporte einlesen und alle Kennzahlen berechnen
# =============================================================================
#
# WAS PASSIERT HIER?  In vier Schritten:
#
#   A) Rohdaten einlesen: alle Batch-CSVs aus data/raw/ untereinander haengen.
#   B) Fundamentals und Estimates verheiraten (ueber Ticker + Quartalsende).
#   C) TTM bilden -- rollierende 4-Quartals-Summen, damit Saisonalitaet raus ist.
#   D) Kennzahlen rechnen -- genau die Formeln aus Tab "04_R_Formeln".
#
# WICHTIG, und das ist der Kern des ganzen Skripts:
# Jede Zeile bekommt ein Feld "known_from". Das ist der Tag, ab dem diese
# Zahlen oeffentlich waren -- also das Berichtsdatum, NICHT das Quartalsende.
# Samsungs Q2-Zahlen zum 30.06. kennt der Markt erst am 31.07. Wer im
# Backtest am 01.07. schon damit rechnet, baut sich eine Zeitmaschine.
#
# Ergebnis: data/proc/fundamentals.rds  (eine Zeile je Ticker x Quartal)
# =============================================================================

source("00_config.R")

# =============================================================================
# A) ROHDATEN EINLESEN
# =============================================================================

# --- A1: Universum (Tab "01_Ticker" als CSV exportiert) ----------------------
# Erwartete Spalten: RIC, ISIN, Common Name, Market, Stichdatum
# Die Batch-Spalte brauchen wir hier nicht.

load_universe <- function(path = CFG$file_universe) {
  stopifnot(file.exists(path))
  u <- fread(path, encoding = "UTF-8")
  setnames(u, tolower(gsub("[^A-Za-z]", "_", names(u))))

  # Spalten flexibel finden, falls die Excel-Ueberschriften leicht abweichen
  col_ric  <- grep("^ric$",    names(u), value = TRUE)[1]
  col_isin <- grep("isin",     names(u), value = TRUE)[1]
  col_name <- grep("name",     names(u), value = TRUE)[1]
  col_mkt  <- grep("market",   names(u), value = TRUE)[1]

  u <- u[, .(id     = get(col_ric),
             isin   = if (!is.na(col_isin)) get(col_isin) else NA_character_,
             name   = if (!is.na(col_name)) get(col_name) else NA_character_,
             market = if (!is.na(col_mkt))  get(col_mkt)  else NA_character_)]

  u <- u[!is.na(id) & nzchar(trimws(id))]
  u <- unique(u, by = "id")

  # Die zwei Uebersetzer aus der Config anwenden
  u[, yahoo       := ric_to_yahoo(id)]
  u[, delist_date := ric_delist_date(id)]
  u[, is_dead     := !is.na(delist_date)]

  msg("Universum: ", nrow(u), " Ticker, davon ", sum(u$is_dead),
      " mit Delisting-Suffix im RIC.")
  if (anyNA(u$yahoo)) {
    bad <- u[is.na(yahoo), unique(sub("^.*\\.", "", sub("\\^.*$", "", id)))]
    warning("Unbekannte Boersenkuerzel (nicht in RIC_EXCHANGE_MAP): ",
            paste(bad, collapse = ", "))
  }
  u[]
}

# --- A2: Fundamentals -------------------------------------------------------
# ACHTUNG, hier steckt ein Fallstrick in deiner Excel-Datei:
#
# Die Kopfzeile in Tab "03_Fundamentals_Export" lautet
#     ..., diluted_shares, total_assets, mktcap_usd, industry, adv_3m
# Die WERTE stehen aber in der Reihenfolge der RDP-Formel aus Tab 02:
#     ..., ShrUsedToCalcDilEPS, CompanyMarketCap, TotAssets, Industry, ADV
#
# Spalte K enthaelt also die Marktkapitalisierung, nicht die Bilanzsumme.
# (Kontrolle Samsung Q2/2019: K = 271,5 Mrd = Market Cap,
#                             L = 296,8 Mrd = Total Assets.)
# Wir lesen deshalb POSITIONSBASIERT ein und pruefen danach mit einer
# Plausibilitaetskontrolle nach, ob die Zuordnung stimmt.

FUND_COLS <- c("id", "period_end", "revenue", "net_income", "gross_profit",
               "total_debt", "total_equity", "op_cashflow", "capex",
               "diluted_shares", "mktcap_usd", "total_assets",
               "industry", "adv_3m")

load_fundamentals <- function(dir = CFG$dir_raw) {
  files <- list.files(dir, pattern = CFG$pattern_fundamentals, full.names = TRUE)
  stopifnot(length(files) > 0)
  msg("Fundamentals: ", length(files), " Datei(en) gefunden.")

  dt <- rbindlist(lapply(files, function(f) {
    x <- fread(f, encoding = "UTF-8", na.strings = c("", "NA", "NULL", "NaN"))
    x <- x[, seq_len(min(ncol(x), length(FUND_COLS))), with = FALSE]
    setnames(x, FUND_COLS[seq_len(ncol(x))])
    x
  }), fill = TRUE)

  # Typen erzwingen
  dt[, period_end := as.Date(substr(as.character(period_end), 1, 10))]
  numcols <- setdiff(FUND_COLS, c("id", "period_end", "industry"))
  for (cc in intersect(numcols, names(dt)))
    dt[, (cc) := suppressWarnings(as.numeric(get(cc)))]
  dt[, id := trimws(as.character(id))]

  # Zeilen ohne Quartalsende sind die "Forecast-Platzhalter" am Ende jedes
  # Ticker-Blocks (nur Market Cap gefuellt) -- die brauchen wir nicht.
  dt <- dt[!is.na(period_end) & !is.na(id)]
  dt <- unique(dt, by = c("id", "period_end"))
  setorder(dt, id, period_end)

  check_column_swap(dt)

  # industry und adv_3m stehen nur in der ERSTEN Zeile je Ticker.
  # industry fuellen wir auf (aendert sich praktisch nie).
  # adv_3m NICHT benutzen -- siehe Kommentar unten.
  dt[, industry := industry[!is.na(industry)][1], by = id]
  dt[is.na(industry), industry := "UNKNOWN"]

  msg("Fundamentals: ", nrow(dt), " Zeilen, ",
      uniqueN(dt$id), " Ticker, ",
      format(min(dt$period_end)), " bis ", format(max(dt$period_end)))
  dt[]
}

#' Plausibilitaetskontrolle Market Cap vs. Total Assets
#'
#' Idee: ueber ein gemischtes Universum ist das Verhaeltnis Bilanzsumme zu
#' Umsatz typischerweise deutlich groesser als 1 (Banken extrem, Industrie ~2-4).
#' Wenn die vermeintliche "total_assets"-Spalte systematisch KLEINER ist als
#' die "mktcap"-Spalte relativ zum Umsatz, sind die beiden vertauscht.
check_column_swap <- function(dt) {
  s <- dt[!is.na(revenue) & revenue > 0 & !is.na(total_assets) &
            !is.na(mktcap_usd)]
  if (nrow(s) < 100) {
    msg("  Hinweis: zu wenige Zeilen fuer die Vertauschungs-Pruefung.")
    return(invisible(NULL))
  }
  # Bilanzsumme/Umsatz sollte im Median hoeher liegen als bei einer
  # falsch zugeordneten Spalte. Wir vergleichen beide Kandidaten.
  ta_ratio <- median(s$total_assets / s$revenue, na.rm = TRUE)
  mc_ratio <- median(s$mktcap_usd  / s$revenue, na.rm = TRUE)
  msg("  Plausibilitaet: Median(total_assets/revenue) = ", round(ta_ratio, 2),
      " | Median(mktcap/revenue) = ", round(mc_ratio, 2))
  msg("  -> Beide Werte sollten > 1 sein. Wirkt eine Spalte wie eine ",
      "Bilanzsumme (oft 5-20x Umsatz bei Finanzwerten), passt die Zuordnung.")
  msg("  -> Bei Zweifel eine bekannte Aktie manuell gegenpruefen, ",
      "z.B. Samsung Q2/2019: Market Cap ~272 Mrd, Total Assets ~297 Mrd USD.")
  invisible(NULL)
}

# --- A3: Estimates ----------------------------------------------------------
EST_COLS <- c("id", "period_end", "report_date", "eps_actual", "eps_mean_est",
              "eps_smart_est", "price_target", "rec_mean", "rev_actual",
              "rev_mean_est", "net_income_loc")

load_estimates <- function(dir = CFG$dir_raw) {
  files <- list.files(dir, pattern = CFG$pattern_estimates, full.names = TRUE)
  stopifnot(length(files) > 0)
  msg("Estimates: ", length(files), " Datei(en) gefunden.")

  dt <- rbindlist(lapply(files, function(f) {
    x <- fread(f, encoding = "UTF-8", na.strings = c("", "NA", "NULL", "NaN"))
    x <- x[, seq_len(min(ncol(x), length(EST_COLS))), with = FALSE]
    setnames(x, EST_COLS[seq_len(ncol(x))])
    x
  }), fill = TRUE)

  dt[, id := trimws(as.character(id))]
  dt[, period_end := as.Date(substr(as.character(period_end), 1, 10))]
  # report_date kommt als "2019-07-31 05:17:00" -- wir brauchen nur den Tag.
  dt[, report_date := as.Date(substr(as.character(report_date), 1, 10))]
  for (cc in setdiff(EST_COLS, c("id", "period_end", "report_date")))
    dt[, (cc) := suppressWarnings(as.numeric(get(cc)))]

  dt <- dt[!is.na(period_end) & !is.na(id)]
  dt <- unique(dt, by = c("id", "period_end"))
  setorder(dt, id, period_end)

  msg("Estimates: ", nrow(dt), " Zeilen, ",
      sum(!is.na(dt$report_date)), " davon mit Berichtsdatum.")
  dt[]
}

# =============================================================================
# B) ZUSAMMENFUEHREN + "KNOWN_FROM" SETZEN
# =============================================================================

build_quarterly <- function(fund, est) {

  dt <- merge(fund, est, by = c("id", "period_end"), all.x = TRUE)
  setorder(dt, id, period_end)

  # --- Der wichtigste Schritt des Skripts -----------------------------------
  # known_from = ab wann waren diese Zahlen oeffentlich?
  # Erste Wahl: das echte Berichtsdatum aus den Estimates.
  # Notfall: Quartalsende + konservativer Lag (Default 75 Tage).
  dt[, known_from := report_date]
  dt[is.na(known_from), known_from := period_end + CFG$report_lag_fallback]
  dt[, report_date_imputed := is.na(report_date)]

  # Ein Berichtsdatum VOR dem Quartalsende ist ein Datenfehler -> korrigieren.
  dt[known_from <= period_end, known_from := period_end + CFG$report_lag_fallback]

  msg("Berichtsdatum imputiert bei ",
      round(100 * mean(dt$report_date_imputed), 1), "% der Quartale.")
  dt[]
}

# =============================================================================
# C) TTM BILDEN
# =============================================================================
# TTM = Trailing Twelve Months = die letzten vier Quartale aufsummiert.
# Warum? Ein einzelnes Quartal ist saisonal verzerrt (Weihnachtsgeschaeft,
# koreanische Chip-Zyklen). Vier Quartale gleichen das aus.
#
# frollsum(x, 4) summiert das aktuelle plus die drei vorherigen Quartale.
# Ist eines davon NA, wird das Ergebnis NA -- genau richtig, denn eine
# Luecke in der Historie darf keine halbe TTM-Zahl produzieren.

add_ttm <- function(dt) {
  setorder(dt, id, period_end)

  # Sicherheitsnetz: es duerfen keine Quartale fehlen, sonst summiert
  # frollsum ueber ein Loch hinweg. Wir markieren Luecken > 100 Tage.
  dt[, gap_days := as.numeric(period_end - shift(period_end)), by = id]
  dt[, has_gap := !is.na(gap_days) & gap_days > 130]
  if (any(dt$has_gap)) {
    msg("Warnung: ", sum(dt$has_gap), " Quartalsluecken > 130 Tage gefunden. ",
        "TTM-Werte direkt nach einer Luecke werden verworfen.")
  }
  # Zaehler, wie viele Quartale seit der letzten Luecke vergangen sind
  dt[, block := cumsum(has_gap), by = id]
  dt[, n_since_gap := seq_len(.N), by = .(id, block)]

  ttm_cols <- c(revenue = "rev_ttm", net_income = "ni_ttm",
                gross_profit = "gp_ttm", op_cashflow = "ocf_ttm",
                capex = "capex_ttm", net_income_loc = "ni_ttm_loc")

  for (src in names(ttm_cols)) {
    tgt <- ttm_cols[[src]]
    dt[, (tgt) := roll_sum(get(src), 4), by = id]
    # Nach einer Luecke sind die ersten drei TTM-Werte kontaminiert
    dt[n_since_gap < 4, (tgt) := NA_real_]
  }

  # Durchschnittliches Eigenkapital der letzten 4 Quartale (Nenner fuer ROE)
  dt[, equity_avg4 := roll_mean(total_equity, 4), by = id]
  dt[n_since_gap < 4, equity_avg4 := NA_real_]

  dt[, c("gap_days", "has_gap", "block") := NULL]
  dt[]
}

# =============================================================================
# D) KENNZAHLEN
# =============================================================================
# Eins zu eins die Formeln aus Tab "04_R_Formeln", plus ein paar Ergaenzungen,
# die fuer PEAD gebraucht werden.

add_metrics <- function(dt) {

  # --- Margen und Bilanz ---------------------------------------------------
  dt[, net_margin   := safe_div(ni_ttm, rev_ttm)]        # FX kuerzt sich raus
  dt[, gross_margin := safe_div(gp_ttm, rev_ttm)]
  dt[, fcf          := ocf_ttm - abs(capex_ttm)]         # abs() wegen
                                                         # Vorzeichen-Chaos
  dt[, fcf_margin   := safe_div(fcf, rev_ttm)]
  dt[, debt_equity  := safe_div(total_debt, total_equity)]
  dt[, eps_ttm      := safe_div(ni_ttm_loc, diluted_shares)]  # Lokalwaehrung!
  dt[, pe           := safe_div(mktcap_usd, ni_ttm)]     # beides USD
  dt[, roe          := safe_div(ni_ttm, equity_avg4)]
  dt[, accruals     := safe_div(ni_ttm - ocf_ttm, total_assets)]  # niedrig=gut

  # Negatives Eigenkapital macht debt_equity und roe sinnlos -> raus
  dt[!is.na(total_equity) & total_equity <= 0,
     c("debt_equity", "roe") := NA_real_]

  # --- Wachstum ------------------------------------------------------------
  setorder(dt, id, period_end)
  dt[, rev_yoy := safe_div(rev_ttm, shift(rev_ttm, 4)) - 1, by = id]

  # BASISEFFEKT-GUARD: Wenn das Vorjahres-EPS negativ war, ist jede
  # Wachstumsrate Unsinn (-2 auf +1 sind "minus 150 Prozent Wachstum").
  dt[, eps_ttm_lag4 := shift(eps_ttm, 4), by = id]
  dt[, eps_yoy := fifelse(!is.na(eps_ttm_lag4) & eps_ttm_lag4 > 0,
                          eps_ttm / eps_ttm_lag4 - 1, NA_real_)]

  # --- Estimates / Surprise ------------------------------------------------
  # Die Prozent-Version aus deinem Tab. Vorsicht: bei einer Schaetzung nahe
  # null explodiert der Wert. Wir behalten sie, aber ranken spaeter lieber
  # ueber die standardisierte Variante weiter unten.
  dt[, eps_surprise  := safe_div(eps_actual - eps_mean_est,
                                 abs(eps_mean_est)) * 100]
  # Vorwaertsgerichtet: SmartEstimate gegen Konsens. Das ist der eigentliche
  # PEAD-Indikator, weil er misst, wo der Konsens noch nachziehen muss.
  dt[, pred_surprise := safe_div(eps_smart_est - eps_mean_est,
                                 abs(eps_mean_est)) * 100]
  dt[, rev_surprise  := safe_div(rev_actual - rev_mean_est,
                                 abs(rev_mean_est)) * 100]

  # SUE (Standardized Unexpected Earnings) -- der Literatur-Standard fuer PEAD.
  # Statt durch die Schaetzung zu teilen, teilen wir durch die
  # Streuung der EIGENEN Surprise-Historie des Titels. Ein Titel, der immer
  # um 3% ueberrascht, bekommt fuer 3% keinen Punkt. Ein Titel, der sonst
  # punktgenau liefert, bekommt fuer 3% viele Punkte.
  dt[, surp_abs := eps_actual - eps_mean_est]
  dt[, surp_sd8 := shift(roll_fun(surp_abs, 8, sd, na.rm = TRUE), 1),
     by = id]                       # shift(): die aktuelle Zahl darf NICHT
                                    # in ihre eigene Normierung einfliessen
  dt[, sue := fifelse(!is.na(surp_sd8) & surp_sd8 > 0,
                      surp_abs / surp_sd8, NA_real_)]
  dt[, sue := pmax(pmin(sue, 10), -10)]   # kappen, sonst dominieren Ausreisser

  # Wie oft hat der Titel zuletzt positiv ueberrascht? (0 bis 1, letzte 4 Q,
  # ohne das aktuelle Quartal)
  dt[, surp_hit := as.integer(surp_abs > 0)]
  dt[, surp_hit_rate4 := shift(roll_mean(surp_hit, 4), 1), by = id]

  dt[, c("surp_abs", "surp_hit", "eps_ttm_lag4") := NULL]
  dt[]
}

# =============================================================================
# HAUPTLAUF
# =============================================================================

if (run_main()) {

  universe <- load_universe()
  fund     <- load_fundamentals()
  est      <- load_estimates()

  q <- build_quarterly(fund, est)
  q <- add_ttm(q)
  q <- add_metrics(q)

  # Nur Ticker behalten, die auch im Universum stehen, und Stammdaten anhaengen
  q <- merge(q, universe[, .(id, name, market, yahoo, delist_date)],
             by = "id", all.x = TRUE)

  # Ein Quartal, das NACH dem Delisting liegt, kann es nicht geben -> raus
  q <- q[is.na(delist_date) | known_from <= delist_date]

  setorder(q, id, period_end)
  setkey(q, id, known_from)

  saveRDS(q,        file.path(CFG$dir_proc, "fundamentals.rds"))
  saveRDS(universe, file.path(CFG$dir_proc, "universe.rds"))

  msg("Fertig. ", nrow(q), " Ticker-Quartale gespeichert.")

  # Kurzer Blick auf die Abdeckung der Kennzahlen -- wenn hier eine Spalte
  # bei 90% NA steht, stimmt am Export etwas nicht.
  check <- c("rev_ttm", "ni_ttm", "roe", "pe", "debt_equity", "fcf_margin",
             "rev_yoy", "eps_yoy", "sue", "pred_surprise")
  cov <- q[, lapply(.SD, function(x) round(100 * mean(!is.na(x)), 1)),
           .SDcols = check]
  print(data.table(kennzahl = names(cov), abdeckung_pct = unlist(cov)))
}
